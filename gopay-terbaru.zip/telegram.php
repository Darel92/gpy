<?php
$id_telegram = "7173287452"; //👈🏻 masukan id tele lu bree di sini 
$id_botTele = "6964240595:AAHzcYXal6nvSJwUpTKbWMyTZM2g2CohACw"; //👈🏻 masukan token bot lu bree
?>
