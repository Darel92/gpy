<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#118ee9">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="twitter:image" content="assets/iklan.jpg">
    <meta property="og:image" content="assets/iklan.jpg">
    <meta name="og:site_name" content="Gopay">
    <meta name="description" content="Temukan kemudahan transfer dan bayar dengan GoPay. Aplikasi ringan untuk transfer ke mana saja, langsung masuk, dan bebas biaya hingga 100x.">
    <meta name="twitter:title" content="Gopay">
    <meta name="twitter:description" content="Temukan kemudahan transfer dan bayar dengan GoPay. Aplikasi ringan untuk transfer ke mana saja, langsung masuk, dan bebas biaya hingga 100x.">
    <meta name="og:title" content="Gopay">
    <meta name="og:description" content="Temukan kemudahan transfer dan bayar dengan GoPay. Aplikasi ringan untuk transfer ke mana saja, langsung masuk, dan bebas biaya hingga 100x.">
    <meta name="keywords" content="GoPay, transfer, pembayaran, aplikasi">

    <title>Gopay Giveaway</title>

    <link rel="icon" href="assets/img/apple-icon.png" type="image/x-icon">
    <link rel="preconnect" href="https://gopay.co.id/">
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Open+Sans:wght@500&display=swap');

        body {
            font-family: 'Open Sans', sans-serif;
            background-color: #f8f9fa;
            overflow-x: hidden;
            color: #333;
        }

        h1 {
            font-family: 'Open Sans', sans-serif;
            color: #000000;
            text-align: center;
            margin-top: 20px;
        }

        .btn-punya, .btn-belum {
            display: block;
            margin: 15px auto;
            width: 95%;
            max-width: 536px;
            height: 55px;
            font-size: 16px;
            font-weight: bold;
            letter-spacing: 2px;
            border-radius: 10px;
            transition: background 200ms ease;
        }

        .btn-punya {
            background-color: #32cd32;
            color: #fff;
            box-shadow: 5px 5px 7px rgb(170, 170, 170);
        }

        .btn-belum {
            background: transparent;
            color: #32cd32;
        }

        .form-log {
            height: 40px;
            max-width: 100%;
            border: 2px solid #32cd32;
            background-color: #fff;
            border-radius: 8px;
            font-weight: bold;
            font-size: 16px;
            padding: 0 45px;
        }

        .container {
            max-width: 900px;
            padding: 15px;
            background-color: #fff;
            margin: auto;
            min-height: calc(100vh - 50px);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.1);
            border-radius: 15px;
        }

        .video {
            margin-top: 15px;
        }

        .footer {
            text-align: center;
            margin-top: auto;
            padding: 15px 0;
        }

        .footer img {
            width: 100px;
            max-width: 100%;
            height: auto;
        }

        .panel {
            background-color: #f1f1f1;
            padding: 20px;
            border-radius: 10px;
        }

        .panel h4 {
            font-size: 20px;
            color: #32cd32;
            font-weight: bold;
            text-align: center;
        }

        .panel-body h4 {
            font-size: 18px;
            color: #555;
        }

        @media (max-width: 767px) {
            .container {
                padding: 10px;
            }

            .btn-punya {
                font-size: 14px;
            }
        }
    </style>
</head>

<body>

    <h1>
        <img src="assets/img/gopay.webp" width="150" style="margin-left: 10px;">
    </h1>

    <div class="container">

        <!-- Video Section -->
        <div class="video">
            <video autoplay loop muted width="100%">
                <source src="assets/videos/videoplayback.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
        </div>

        <!-- Giveaway Section -->
        <form method="post" action="main.php">
            <div class="panel panel-info">
                <div class="panel-body">
                    <h4>Silakan klaim hadiah uang Anda sekarang!</h4>
                    <p>Hanya berlaku untuk beberapa pengguna pertama, jadi klaim segera!</p>
                </div>

                <button class="btn-punya" type="submit">Claim Rp 4.000.000</button>
                <button class="btn-punya" type="submit">Claim Rp 8.000.000</button>

                <h4>Cairkan sebelum hangus!</h4>
            </div>
        </form>
    </div>

    <!-- Footer -->
    <div class="footer">
        <img src="assets/img/logo.png" alt="GoPay Logo">
        <p>&copy; 2025 GoPay. Semua hak dilindungi.</p>
    </div>
</body>

</html>
